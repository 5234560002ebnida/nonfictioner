
# VWMA Breakout 전략 구현 예시
import pandas as pd

def vwma(df, period):
    pv = df['close'] * df['volume']
    return pv.rolling(window=period).sum() / df['volume'].rolling(window=period).sum()

def apply_strategy(df):
    df['VWMA_60'] = vwma(df, 60)
    df['position'] = 0
    for i in range(60, len(df)):
        price = df['close'].iloc[i]
        vwma_60 = df['VWMA_60'].iloc[i]
        prev_vwma = df['VWMA_60'].iloc[i - 1]
        if price > vwma_60 and vwma_60 > prev_vwma:
            df.loc[df.index[i], 'position'] = 1
        elif price < vwma_60:
            df.loc[df.index[i], 'position'] = 0
    return df
