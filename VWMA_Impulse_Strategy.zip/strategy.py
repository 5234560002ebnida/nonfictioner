
# VWMA Impulse Strategy
import pandas as pd

def vwma(df, period):
    pv = df['close'] * df['volume']
    return pv.rolling(window=period).sum() / df['volume'].rolling(window=period).sum()

def apply_strategy(df):
    df['VWMA_60'] = vwma(df, 60)
    df['vol_ma20'] = df['volume'].rolling(window=20).mean()
    df['position'] = 0
    for i in range(60, len(df)):
        price = df['close'].iloc[i]
        prev_price = df['close'].iloc[i - 1]
        vwma_now = df['VWMA_60'].iloc[i]
        prev_vwma = df['VWMA_60'].iloc[i - 1]
        vol = df['volume'].iloc[i]
        vol_avg = df['vol_ma20'].iloc[i]
        is_bullish = price > prev_price

        if price > vwma_now and vol > 2 * vol_avg and is_bullish:
            df.loc[df.index[i], 'position'] = 1
        elif price < vwma_now:
            df.loc[df.index[i], 'position'] = 0
    return df
